from django.contrib.auth.decorators import user_passes_test
from django.core.exceptions import PermissionDenied
from django.contrib.auth.mixins import UserPassesTestMixin

def manager_required(view_func):
    def test_func(user):
        return hasattr(user, 'userrole') and user.userrole.role in ['MANAGER', 'ADMIN']
    return user_passes_test(test_func)(view_func)

def admin_required(view_func):
    def test_func(user):
        return hasattr(user, 'userrole') and user.userrole.role == 'ADMIN'
    return user_passes_test(test_func)(view_func)

class ManagerRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return hasattr(self.request.user, 'userrole') and self.request.user.userrole.role in ['MANAGER', 'ADMIN']

class AdminRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return hasattr(self.request.user, 'userrole') and self.request.user.userrole.role == 'ADMIN'