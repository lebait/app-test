from django.contrib.auth.mixins import UserPassesTestMixin
from django.core.exceptions import PermissionDenied

class ManagerRequiredMixin(UserPassesTestMixin):
    """Mixin to verify the user has manager or admin privileges."""
    
    def test_func(self):
        user = self.request.user
        if not user.is_authenticated:
            return False
        # Check if user has UserRole and is manager or admin
        if hasattr(user, 'userrole'):
            return user.userrole.role in ['MANAGER', 'ADMIN']
        return False
    
    def handle_no_permission(self):
        raise PermissionDenied("You don't have permission to access this page.")

class AdminRequiredMixin(UserPassesTestMixin):
    """Mixin to verify the user has admin privileges."""
    
    def test_func(self):
        user = self.request.user
        if not user.is_authenticated:
            return False
        # Check if user has UserRole and is admin
        if hasattr(user, 'userrole'):
            return user.userrole.role == 'ADMIN'
        return False
    
    def handle_no_permission(self):
        raise PermissionDenied("You don't have permission to access this page.")