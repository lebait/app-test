from django.db import models
from django.contrib.auth.models import User

class Agent(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=20)
    address = models.TextField()
    registration_date = models.DateTimeField(auto_now_add=True)
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.user.username})"

class Customer(models.Model):
    name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)
    id_number = models.CharField(max_length=50, blank=True, null=True)
    registration_date = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name

class TransactionType(models.Model):
    name = models.CharField(max_length=50)
    code = models.CharField(max_length=10, unique=True)
    is_deposit = models.BooleanField(default=False)  # True for deposit, False for withdrawal

    def __str__(self):
        return self.name

class Transaction(models.Model):
    agent = models.ForeignKey(Agent, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.SET_NULL, null=True, blank=True)
    transaction_type = models.ForeignKey(TransactionType, on_delete=models.PROTECT)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    fee = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    reference = models.CharField(max_length=100, blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    is_completed = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.transaction_type} - {self.amount}"

    def save(self, *args, **kwargs):
        # Update agent balance when transaction is completed
        if self.is_completed:
            agent = self.agent
            if self.transaction_type.is_deposit:
                agent.balance += self.amount
            else:
                agent.balance -= self.amount
            agent.save()
        super().save(*args, **kwargs)
        
class UserRole(models.Model):
    ROLE_CHOICES = [
        ('AGENT', 'Agent'),
        ('MANAGER', 'Manager'),
        ('ADMIN', 'Administrator'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='AGENT')

    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"
    
class UserRole(models.Model):
    ROLE_CHOICES = [
        ('AGENT', 'Agent'),
        ('MANAGER', 'Manager'),
        ('ADMIN', 'Administrator'),
    ]
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='AGENT')

    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"