from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Q
from datetime import date, timedelta
from django.views.generic import ListView

from .models import Agent, Customer, Transaction, TransactionType
from .forms import CustomerForm, TransactionForm
from .decorators import manager_required, admin_required
from .mixins import ManagerRequiredMixin, AdminRequiredMixin


@login_required
def dashboard(request):
    agent, created = Agent.objects.get_or_create(
        user=request.user,
        defaults={'phone_number': ""}
    )
        
    transactions = Transaction.objects.filter(agent=agent).order_by('-timestamp')[:10]
    context = {
        'agent': agent,
        'transactions': transactions,
    }
    return render(request, 'accounting/dashboard.html', context)


@login_required
def customer_list(request):
    agent = get_object_or_404(Agent, user=request.user)
    customers = Customer.objects.all()
    return render(request, 'accounting/customer_list.html', {'customers': customers})


@login_required
def add_customer(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('customer_list')
    else:
        form = CustomerForm()
    return render(request, 'accounting/customer_form.html', {'form': form})


@login_required
def transaction_list(request):
    agent = get_object_or_404(Agent, user=request.user)
    transactions = Transaction.objects.filter(agent=agent).order_by('-timestamp')
    return render(request, 'accounting/transaction_list.html', {'transactions': transactions})


@login_required
def add_transaction(request):
    agent = get_object_or_404(Agent, user=request.user)
    
    if request.method == 'POST':
        form = TransactionForm(agent, request.POST)
        if form.is_valid():
            transaction = form.save(commit=False)
            transaction.agent = agent
            transaction.save()
            return redirect('transaction_list')
    else:
        form = TransactionForm(agent)
    
    return render(request, 'accounting/transaction_form.html', {'form': form})


@admin_required
def admin_dashboard(request):
    # Admin-specific view
    pass


class AllTransactionsListView(ManagerRequiredMixin, ListView):
    model = Transaction
    template_name = 'accounting/all_transactions.html'
    context_object_name = 'transactions'
    ordering = ['-timestamp']
    

@manager_required
def daily_summary(request):
    today = date.today()
    yesterday = today - timedelta(days=1)
    
    # Today's transactions
    today_transactions = Transaction.objects.filter(
        timestamp__date=today
    ).select_related('transaction_type', 'agent', 'customer')
    
    # Summary data
    summary = today_transactions.values(
        'transaction_type__name', 'transaction_type__is_deposit'
    ).annotate(
        total_amount=Sum('amount'),
        total_fee=Sum('fee'),
        count=Count('id')
    )
    
    # Yesterday comparison
    yesterday_total = Transaction.objects.filter(
        timestamp__date=yesterday
    ).aggregate(
        total_amount=Sum('amount'),
        total_fee=Sum('fee')
    )
    
    context = {
        'today': today,
        'transactions': today_transactions,
        'summary': summary,
        'yesterday_total': yesterday_total,
    }
    
    return render(request, 'accounting/reports/daily_summary.html', context)


@login_required
def customer_transaction_history(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    transactions = Transaction.objects.filter(
        customer=customer
    ).order_by('-timestamp')
    
    # Calculate totals
    totals = transactions.aggregate(
        total_deposits=Sum('amount', filter=Q(transaction_type__is_deposit=True)),
        total_withdrawals=Sum('amount', filter=Q(transaction_type__is_deposit=False)),
        total_fees=Sum('fee')
    )
    
    context = {
        'customer': customer,
        'transactions': transactions,
        'totals': totals,
    }
    
    return render(request, 'accounting/reports/customer_history.html', context)


def custom_404(request, exception):
    return render(request, 'accounting/404.html', status=404)


def custom_500(request):
    return render(request, 'accounting/500.html', status=500)