from django.contrib import admin
from .models import Agent, Customer, TransactionType, Transaction

class AgentAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'balance')
    search_fields = ('user__username', 'user__first_name', 'user__last_name', 'phone_number')

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone_number', 'id_number', 'registration_date')
    search_fields = ('name', 'phone_number', 'id_number')

class TransactionTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'is_deposit')

class TransactionAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'agent', 'customer', 'transaction_type', 'amount', 'is_completed')
    list_filter = ('transaction_type', 'is_completed', 'timestamp')
    search_fields = ('agent__user__username', 'customer__name', 'reference')

admin.site.register(Agent, AgentAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(TransactionType, TransactionTypeAdmin)
admin.site.register(Transaction, TransactionAdmin)

from .models import UserRole

class UserRoleAdmin(admin.ModelAdmin):
    list_display = ('user', 'role')
    list_filter = ('role',)
    search_fields = ('user__username', 'user__first_name', 'user__last_name')

admin.site.register(UserRole, UserRoleAdmin)