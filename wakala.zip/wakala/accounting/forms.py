from django import forms
from .models import Customer, Transaction, TransactionType, Agent

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ['name', 'phone_number', 'id_number', 'notes']

class TransactionForm(forms.ModelForm):
    def __init__(self, agent, *args, **kwargs):
        super(TransactionForm, self).__init__(*args, **kwargs)
        self.fields['customer'].queryset = Customer.objects.all()
        self.fields['transaction_type'].queryset = TransactionType.objects.all()
    
    class Meta:
        model = Transaction
        fields = ['customer', 'transaction_type', 'amount', 'fee', 'reference', 'notes']
        
        def clean(self):
        cleaned_data = super().clean()
        amount = cleaned_data.get('amount')
        transaction_type = cleaned_data.get('transaction_type')
        agent = self.agent
        
        if amount and transaction_type and agent:
            if not transaction_type.is_deposit and amount > agent.balance:
                raise forms.ValidationError(
                    "Insufficient balance for this withdrawal."
                )
        
        return cleaned_data