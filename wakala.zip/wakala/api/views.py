from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from accounting.models import Agent, Customer, Transaction
from .serializers import (
    AgentSerializer, CustomerSerializer,
    TransactionSerializer, TransactionCreateSerializer
)
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from django.db.models import Sum
from datetime import datetime, timedelta

class StandardResultsSetPagination(PageNumberPagination):
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100

class AgentViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Agent.objects.all()
    serializer_class = AgentSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsSetPagination

    @action(detail=False, methods=['get'])
    def me(self, request):
        try:
            agent = get_object_or_404(Agent, user=request.user)
            serializer = self.get_serializer(agent)
            return Response(serializer.data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CustomerViewSet(viewsets.ModelViewSet):
    queryset = Customer.objects.all()
    serializer_class = CustomerSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['name', 'phone_number']

    def get_queryset(self):
        if hasattr(self.request.user, 'agent'):
            return Customer.objects.all()
        return Customer.objects.none()

class TransactionViewSet(viewsets.ModelViewSet):
    queryset = Transaction.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['transaction_type', 'customer', 'timestamp']

    def get_serializer_class(self):
        if self.action in ['create', 'update', 'partial_update']:
            return TransactionCreateSerializer
        return TransactionSerializer

    def perform_create(self, serializer):
        try:
            agent = get_object_or_404(Agent, user=self.request.user)
            serializer.save(agent=agent)
        except Exception as e:
            raise serializers.ValidationError(str(e))

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'agent'):
            return Transaction.objects.filter(agent=user.agent)
        return Transaction.objects.none()

    @action(detail=False, methods=['get'])
    def summary(self, request):
        try:
            agent = get_object_or_404(Agent, user=request.user)
            transactions = Transaction.objects.filter(agent=agent)
            
            # Optional date filtering
            date_from = request.query_params.get('date_from')
            date_to = request.query_params.get('date_to')
            
            if date_from:
                transactions = transactions.filter(timestamp__gte=datetime.strptime(date_from, '%Y-%m-%d'))
            if date_to:
                transactions = transactions.filter(timestamp__lte=datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1))
            
            data = {
                'balance': agent.balance,
                'total_deposits': transactions.filter(
                    transaction_type__is_deposit=True
                ).aggregate(total=Sum('amount'))['total'] or 0,
                'total_withdrawals': transactions.filter(
                    transaction_type__is_deposit=False
                ).aggregate(total=Sum('amount'))['total'] or 0,
                'total_fees': transactions.aggregate(total=Sum('fee'))['total'] or 0,
                'transaction_count': transactions.count(),
            }
            
            return Response(data)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)