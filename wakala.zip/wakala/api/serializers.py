from rest_framework import serializers
from accounting.models import Agent, Customer, Transaction, TransactionType
from django.contrib.auth.models import User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name']

class AgentSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    
    class Meta:
        model = Agent
        fields = ['id', 'user', 'phone_number', 'balance']

class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = ['id', 'name', 'phone_number', 'id_number', 'registration_date']

class TransactionTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TransactionType
        fields = ['id', 'name', 'code', 'is_deposit']

class TransactionSerializer(serializers.ModelSerializer):
    customer = CustomerSerializer()
    transaction_type = TransactionTypeSerializer()
    agent = AgentSerializer()
    
    class Meta:
        model = Transaction
        fields = [
            'id', 'agent', 'customer', 'transaction_type', 
            'amount', 'fee', 'reference', 'timestamp'
        ]

class TransactionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = [
            'customer', 'transaction_type', 'amount', 
            'fee', 'reference', 'notes'
        ]
    
    def validate(self, data):
        # Add custom validation here
        return data